#!/usr/bin/env bash
set -euo pipefail
mkdir -p outputs figures
python src/run_demo.py
python src/cpsat_model_template.py
python src/cpsat_smoothness_model_template.py
python src/dwave_cqm_runner.py --summary-only || true
python - <<'PY'
import json, csv
from pathlib import Path
root=Path('.')
rows=[]
for name, file in [('DP feasible baseline','outputs/demo_solution.json'),('CP-SAT linear','outputs/cpsat_solution.json'),('CP-SAT smooth','outputs/cpsat_smooth_solution.json')]:
    data=json.loads(Path(file).read_text())
    if name.startswith('DP'):
        m=data['solution']['metrics']; status='-'; objective=m.get('objective_cost')
    else:
        m=data['metrics']; status=data['status']; objective=data.get('objective')
    rows.append({
        'Method': name, 'Status': status, 'Feasible': m['feasible'], 'Length': m['length'], 'Turns': m['turns'],
        'Buffer': m['buffer_steps'], 'Visibility': m['visibility_rate'], 'Tracking': m['tracking_rate'],
        'ObstacleFree': m['obstacle_free_rate'], 'ValidMotion': m['valid_motion_rate'], 'Acceleration': m['acceleration_cost'],
        'Objective': objective, 'Runtime_s': data.get('runtime_s','-')
    })
out=Path('outputs/final_results_summary.csv')
with out.open('w',newline='') as f:
    w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)
print(out)
PY
