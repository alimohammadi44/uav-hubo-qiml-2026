# Second Paper Final Draft Package

## Paper
- `paper/occlusion_cqm_target_tracking_final.pdf`: current full paper draft.
- `paper/occlusion_cqm_target_tracking_final.tex`: LaTeX source.

## Verified results in this package
- DP feasible baseline: `outputs/demo_solution.json`
- CP-SAT linear exact baseline: `outputs/cpsat_solution.json`
- CP-SAT smooth exact baseline: `outputs/cpsat_smooth_solution.json`
- Summary table: `outputs/final_results_summary.csv`
- D-Wave CQM model statistics: `outputs/dwave_cqm_summary.json`

## Current confirmed final results
- CP-SAT smooth status: OPTIMAL
- Runtime: 3.521 s
- x variables: 499
- y variables: 3461
- smoothness auxiliary variables: 23311
- Path length: 10.657
- Turns: 5
- Buffer steps: 0
- Visibility: 100%
- Tracking feasibility: 100%
- Obstacle-free rate: 100%
- Valid-motion rate: 100%
- Acceleration cost: 6.0

## Code
Run from the package root:

```bash
conda activate occlusion_cqm
python src/run_demo.py
python src/cpsat_model_template.py
python src/cpsat_smoothness_model_template.py
python src/dwave_cqm_runner.py --summary-only
```

To submit to D-Wave Leap, install/configure D-Wave Ocean and run:

```bash
python -m pip install dimod dwave-system
python src/dwave_cqm_runner.py --submit --time-limit 60
```

A real D-Wave result is not included because no authenticated D-Wave run has been provided.
