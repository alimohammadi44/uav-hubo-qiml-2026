"""
Smoothness-augmented CP-SAT exact baseline for occlusion-aware UAV target tracking.

This model linearizes the quadratic smoothness term
    y[t,i,j] * y[t+1,j,k]
using auxiliary binary variables z[t,i,j,k]. It is intended as the exact
classical baseline for the same objective used in the CQM formulation.

Run from the project root:
    python src/cpsat_smoothness_model_template.py
"""
from __future__ import annotations
from pathlib import Path
import json
from occlusion_tracking_core import (
    make_demo_instance, feasible_sets, valid_transition, dist, obstacle_risk, evaluate_path
)

try:
    from ortools.sat.python import cp_model
except Exception as e:
    raise SystemExit("OR-Tools is not installed. Run: python -m pip install ortools") from e


def solve_with_cpsat_smooth(time_limit_s: float = 60.0):
    inst = make_demo_instance()
    F = feasible_sets(inst)
    model = cp_model.CpModel()
    SCALE = 1000

    x = {}
    for t, Ft in enumerate(F):
        for p in Ft:
            x[(t, p)] = model.NewBoolVar(f"x_{t}_{p[0]}_{p[1]}")

    y = {}
    for t in range(inst.T):
        for p in F[t]:
            for q in F[t + 1]:
                if valid_transition(inst, p, q):
                    y[(t, p, q)] = model.NewBoolVar(
                        f"y_{t}_{p[0]}_{p[1]}__{q[0]}_{q[1]}"
                    )

    # One position per time and start constraint.
    for t, Ft in enumerate(F):
        model.Add(sum(x[(t, p)] for p in Ft) == 1)
    model.Add(x[(0, inst.start)] == 1)

    # Flow constraints.
    for t in range(inst.T):
        for p in F[t]:
            out = [y[(t, p, q)] for q in F[t + 1] if (t, p, q) in y]
            model.Add(sum(out) == x[(t, p)])
        for q in F[t + 1]:
            inc = [y[(t, p, q)] for p in F[t] if (t, p, q) in y]
            model.Add(sum(inc) == x[(t + 1, q)])

    objective_terms = []
    obs = set(inst.obstacles)

    # Linear transition/location part.
    for (t, p, q), var in y.items():
        coeff = (
            inst.w_len * dist(p, q)
            + inst.w_track * (dist(q, inst.target[t + 1]) - inst.desired_d) ** 2
            + inst.w_obs * obstacle_risk(q, obs)
        )
        objective_terms.append(int(round(SCALE * coeff)) * var)

    # Linearize smoothness term with z variables.
    z_count = 0
    for t in range(inst.T - 1):
        # pairs of consecutive transitions p->q and q->k
        for p in F[t]:
            for q in F[t + 1]:
                if (t, p, q) not in y:
                    continue
                y1 = y[(t, p, q)]
                for k in F[t + 2]:
                    if (t + 1, q, k) not in y:
                        continue
                    y2 = y[(t + 1, q, k)]
                    zvar = model.NewBoolVar(
                        f"z_{t}_{p[0]}_{p[1]}__{q[0]}_{q[1]}__{k[0]}_{k[1]}"
                    )
                    # z = y1 AND y2
                    model.Add(zvar <= y1)
                    model.Add(zvar <= y2)
                    model.Add(zvar >= y1 + y2 - 1)
                    ax = (k[0] - q[0]) - (q[0] - p[0])
                    ay = (k[1] - q[1]) - (q[1] - p[1])
                    acc = ax * ax + ay * ay
                    coeff = inst.w_smooth * acc
                    objective_terms.append(int(round(SCALE * coeff)) * zvar)
                    z_count += 1

    model.Minimize(sum(objective_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit_s
    solver.parameters.num_search_workers = 8
    status = solver.Solve(model)
    status_name = solver.StatusName(status)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {"status": status_name, "num_x_vars": len(x), "num_y_vars": len(y), "num_z_vars": z_count}

    path = []
    for t, Ft in enumerate(F):
        chosen = [p for p in Ft if solver.Value(x[(t, p)]) == 1]
        path.append(chosen[0])

    metrics = evaluate_path(inst, path)
    return {
        "status": status_name,
        "objective": solver.ObjectiveValue() / SCALE,
        "runtime_s": solver.WallTime(),
        "path": path,
        "metrics": metrics,
        "num_x_vars": len(x),
        "num_y_vars": len(y),
        "num_z_vars": z_count,
    }


if __name__ == "__main__":
    res = solve_with_cpsat_smooth()
    out = Path(__file__).resolve().parents[1] / "outputs" / "cpsat_smooth_solution.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
