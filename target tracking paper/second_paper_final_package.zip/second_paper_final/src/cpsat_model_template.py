"""
CP-SAT exact baseline template for the second paper.

This file requires OR-Tools:
    python -m pip install ortools

It builds the time-expanded binary model from occlusion_tracking_core.py.
The visibility, obstacle, and tracking-distance constraints are handled by
precomputed feasible sets F_t. Transition consistency is enforced with y variables.
A linear objective is included here; smoothness can be added by auxiliary z variables.
"""
from __future__ import annotations
from pathlib import Path
import json, math
from occlusion_tracking_core import make_demo_instance, feasible_sets, valid_transition, dist, obstacle_risk, evaluate_path

try:
    from ortools.sat.python import cp_model
except Exception as e:
    raise SystemExit("OR-Tools is not installed. Run: python -m pip install ortools") from e


def solve_with_cpsat(time_limit_s: float = 30.0):
    inst = make_demo_instance()
    F = feasible_sets(inst)
    model = cp_model.CpModel()

    # x[t,p]
    x = {}
    for t, Ft in enumerate(F):
        for p in Ft:
            x[(t,p)] = model.NewBoolVar(f"x_{t}_{p[0]}_{p[1]}")

    # y[t,p,q]
    y = {}
    for t in range(inst.T):
        for p in F[t]:
            for q in F[t+1]:
                if valid_transition(inst, p, q):
                    y[(t,p,q)] = model.NewBoolVar(f"y_{t}_{p[0]}_{p[1]}__{q[0]}_{q[1]}")

    # one position per time
    for t, Ft in enumerate(F):
        model.Add(sum(x[(t,p)] for p in Ft) == 1)

    # start
    model.Add(x[(0,inst.start)] == 1)

    # flow constraints
    for t in range(inst.T):
        for p in F[t]:
            out = [y[(t,p,q)] for q in F[t+1] if (t,p,q) in y]
            model.Add(sum(out) == x[(t,p)])
        for q in F[t+1]:
            inc = [y[(t,p,q)] for p in F[t] if (t,p,q) in y]
            model.Add(sum(inc) == x[(t+1,q)])

    # Objective: integer-scaled path length + tracking error + obstacle risk.
    SCALE = 1000
    objective_terms = []
    obs = set(inst.obstacles)
    for (t,p,q), var in y.items():
        coeff = inst.w_len*dist(p,q) + inst.w_track*(dist(q, inst.target[t+1])-inst.desired_d)**2 + inst.w_obs*obstacle_risk(q,obs)
        objective_terms.append(int(round(SCALE*coeff))*var)
    model.Minimize(sum(objective_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit_s
    solver.parameters.num_search_workers = 8
    status = solver.Solve(model)

    status_name = solver.StatusName(status)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {"status": status_name}

    path = []
    for t, Ft in enumerate(F):
        chosen = [p for p in Ft if solver.Value(x[(t,p)]) == 1]
        path.append(chosen[0])
    metrics = evaluate_path(inst, path)
    return {
        "status": status_name,
        "objective": solver.ObjectiveValue()/SCALE,
        "runtime_s": solver.WallTime(),
        "path": path,
        "metrics": metrics,
        "num_x_vars": len(x),
        "num_y_vars": len(y),
    }

if __name__ == '__main__':
    res = solve_with_cpsat()
    out = Path(__file__).resolve().parents[1] / 'outputs' / 'cpsat_solution.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
