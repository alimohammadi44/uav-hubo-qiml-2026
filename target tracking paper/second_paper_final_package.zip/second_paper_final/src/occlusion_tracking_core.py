from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple, Optional, Iterable
import math, json, heapq

Point = Tuple[int,int]

@dataclass
class Instance:
    W: int
    H: int
    T: int
    target: List[Point]
    obstacles: List[Point]
    start: Point
    d_min: float = 2.0
    d_max: float = 5.0
    v_max: float = 2.0
    desired_d: float = 3.0
    w_len: float = 1.0
    w_track: float = 0.20
    w_smooth: float = 0.35
    w_obs: float = 0.40


def bresenham(a: Point, b: Point) -> List[Point]:
    x0,y0=a; x1,y1=b
    dx=abs(x1-x0); dy=abs(y1-y0)
    sx=1 if x0<x1 else -1
    sy=1 if y0<y1 else -1
    err=dx-dy
    pts=[]
    while True:
        pts.append((x0,y0))
        if x0==x1 and y0==y1:
            break
        e2=2*err
        if e2>-dy:
            err-=dy; x0+=sx
        if e2<dx:
            err+=dx; y0+=sy
    return pts

def los_clear(a: Point, b: Point, obstacles: set[Point]) -> bool:
    # endpoints are not obstacle-crossing tests; the target and chaser cell are allowed endpoints
    for p in bresenham(a,b)[1:-1]:
        if p in obstacles:
            return False
    return True

def dist(a: Point, b: Point) -> float:
    return math.hypot(a[0]-b[0], a[1]-b[1])

def all_cells(inst: Instance) -> List[Point]:
    return [(x,y) for x in range(inst.W) for y in range(inst.H)]

def obstacle_risk(p: Point, obstacles: set[Point]) -> float:
    if not obstacles:
        return 0.0
    d = min(dist(p,o) for o in obstacles)
    return 1.0/(0.25+d)

def feasible_sets(inst: Instance) -> List[List[Point]]:
    obs=set(inst.obstacles)
    sets=[]
    for t,r in enumerate(inst.target):
        F=[]
        for p in all_cells(inst):
            if p in obs:
                continue
            d=dist(p,r)
            if d < inst.d_min-1e-9 or d > inst.d_max+1e-9:
                continue
            if not los_clear(p,r,obs):
                continue
            F.append(p)
        sets.append(F)
    return sets

def valid_transition(inst: Instance, p: Point, q: Point) -> bool:
    return dist(p,q) <= inst.v_max + 1e-9

def transition_cost(inst: Instance, p: Point, q: Point, t_next: int) -> float:
    # Cost of moving p->q and then being at q at time t_next
    return inst.w_len*dist(p,q) + inst.w_track*(dist(q, inst.target[t_next])-inst.desired_d)**2 + inst.w_obs*obstacle_risk(q,set(inst.obstacles))

def smooth_cost(inst: Instance, prev: Optional[Point], p: Point, q: Point) -> float:
    if prev is None:
        return 0.0
    vx1=p[0]-prev[0]; vy1=p[1]-prev[1]
    vx2=q[0]-p[0]; vy2=q[1]-p[1]
    return inst.w_smooth*((vx2-vx1)**2 + (vy2-vy1)**2)

def solve_dp(inst: Instance) -> Dict:
    F=feasible_sets(inst)
    obs=set(inst.obstacles)
    if inst.start not in F[0]:
        raise ValueError(f"Start {inst.start} is not feasible at t=0; feasible count={len(F[0])}")
    # DP state: at time t, current p, previous p. Store min cost and predecessor.
    # Initialize with state (t=0, curr=start, prev=None)
    current={(inst.start, None): 0.0}
    parent=[]
    parents=[]
    for t in range(inst.T):
        next_states={}
        par={}
        for (p,prev),cost in current.items():
            for q in F[t+1]:
                if not valid_transition(inst,p,q):
                    continue
                c=cost + transition_cost(inst,p,q,t+1) + smooth_cost(inst,prev,p,q)
                key=(q,p)
                if key not in next_states or c<next_states[key]:
                    next_states[key]=c
                    par[key]=(p,prev)
        if not next_states:
            raise ValueError(f"No feasible transition from t={t} to t={t+1}")
        parents.append(par)
        current=next_states
    best_key,best_cost=min(current.items(), key=lambda kv: kv[1])
    # reconstruct
    path=[best_key[0]]
    key=best_key
    for t in range(inst.T-1,-1,-1):
        prev_key=parents[t][key]
        path.append(prev_key[0])
        key=prev_key
    path=list(reversed(path))
    metrics=evaluate_path(inst,path)
    metrics['objective_cost']=best_cost
    return {'path':path,'metrics':metrics,'feasible_counts':[len(s) for s in F]}

def turns(path: List[Point]) -> int:
    count=0
    prev_vec=None
    for a,b in zip(path[:-1],path[1:]):
        v=(b[0]-a[0], b[1]-a[1])
        if prev_vec is not None and v != prev_vec:
            count += 1
        prev_vec=v
    return count

def evaluate_path(inst: Instance, path: List[Point]) -> Dict:
    obs=set(inst.obstacles)
    feasible=True
    reasons=[]
    visible=0
    track_ok=0
    obstacle_free=0
    valid_moves=0
    buffer_steps=0
    length=0.0
    acc_cost=0.0
    for t,p in enumerate(path):
        if p not in obs:
            obstacle_free+=1
        else:
            feasible=False; reasons.append(f'obstacle at t={t}')
        d=dist(p,inst.target[t])
        if inst.d_min-1e-9 <= d <= inst.d_max+1e-9:
            track_ok+=1
        else:
            feasible=False; reasons.append(f'distance at t={t}')
        if los_clear(p,inst.target[t],obs):
            visible+=1
        else:
            feasible=False; reasons.append(f'occlusion at t={t}')
        if obstacle_risk(p,obs) > 1/(0.25+1.5):
            buffer_steps += 1
    for t,(a,b) in enumerate(zip(path[:-1],path[1:])):
        length += dist(a,b)
        if valid_transition(inst,a,b):
            valid_moves += 1
        else:
            feasible=False; reasons.append(f'invalid move {t}->{t+1}')
    for a,b,c in zip(path[:-2],path[1:-1],path[2:]):
        vx1=b[0]-a[0]; vy1=b[1]-a[1]
        vx2=c[0]-b[0]; vy2=c[1]-b[1]
        acc_cost += (vx2-vx1)**2 + (vy2-vy1)**2
    return {
        'feasible': feasible,
        'reasons': reasons,
        'length': length,
        'turns': turns(path),
        'buffer_steps': buffer_steps,
        'visibility_rate': visible/len(path),
        'tracking_rate': track_ok/len(path),
        'obstacle_free_rate': obstacle_free/len(path),
        'valid_motion_rate': valid_moves/(len(path)-1),
        'acceleration_cost': acc_cost,
    }

def make_demo_instance() -> Instance:
    obstacles=[]
    # A wall/cluster that can occlude the target but leaves passages.
    obstacles += [(5,y) for y in range(3,8)]
    obstacles += [(6,6),(7,6)]
    # Another small block.
    obstacles += [(3,8),(4,8)]
    target=[(2,2),(3,2),(4,3),(5,3),(6,4),(7,4),(8,5),(9,5),(9,6),(9,7),(9,8),(9,9)]
    return Instance(W=12,H=12,T=len(target)-1,target=target,obstacles=obstacles,start=(0,2),d_min=2.0,d_max=5.0,desired_d=3.0, v_max=2.0)

if __name__ == '__main__':
    inst=make_demo_instance()
    sol=solve_dp(inst)
    print(json.dumps({'path':sol['path'],'metrics':sol['metrics'],'feasible_counts':sol['feasible_counts']},indent=2))
