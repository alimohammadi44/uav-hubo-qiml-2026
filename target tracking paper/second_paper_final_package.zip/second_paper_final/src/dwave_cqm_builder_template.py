"""
D-Wave CQM builder template for occlusion-aware target tracking.

Requires:
    python -m pip install dimod dwave-system

To submit to D-Wave Leap, uncomment the LeapHybridCQMSampler section and
configure your D-Wave API token/environment.
"""
from __future__ import annotations
from pathlib import Path
import json, math
from occlusion_tracking_core import make_demo_instance, feasible_sets, valid_transition, dist, obstacle_risk

try:
    import dimod
except Exception as e:
    raise SystemExit("dimod is not installed. Run: python -m pip install dimod dwave-system") from e


def build_cqm():
    inst = make_demo_instance()
    F = feasible_sets(inst)
    cqm = dimod.ConstrainedQuadraticModel()

    x = {}
    for t, Ft in enumerate(F):
        for p in Ft:
            name = f"x_{t}_{p[0]}_{p[1]}"
            x[(t,p)] = dimod.Binary(name)

    y = {}
    for t in range(inst.T):
        for p in F[t]:
            for q in F[t+1]:
                if valid_transition(inst,p,q):
                    name = f"y_{t}_{p[0]}_{p[1]}__{q[0]}_{q[1]}"
                    y[(t,p,q)] = dimod.Binary(name)

    # One selected position per time.
    for t, Ft in enumerate(F):
        cqm.add_constraint(sum(x[(t,p)] for p in Ft) == 1, label=f"one_position_t{t}")

    # Start.
    cqm.add_constraint(x[(0,inst.start)] == 1, label="start_position")

    # Flow consistency.
    for t in range(inst.T):
        for p in F[t]:
            out = [y[(t,p,q)] for q in F[t+1] if (t,p,q) in y]
            cqm.add_constraint(sum(out) - x[(t,p)] == 0, label=f"out_{t}_{p}")
        for q in F[t+1]:
            inc = [y[(t,p,q)] for p in F[t] if (t,p,q) in y]
            cqm.add_constraint(sum(inc) - x[(t+1,q)] == 0, label=f"in_{t+1}_{q}")

    obs=set(inst.obstacles)
    objective = 0
    for (t,p,q), var in y.items():
        coeff = inst.w_len*dist(p,q) + inst.w_track*(dist(q, inst.target[t+1])-inst.desired_d)**2 + inst.w_obs*obstacle_risk(q,obs)
        objective += coeff*var

    # Quadratic smoothness term on consecutive transitions.
    for t in range(inst.T-1):
        for p in F[t]:
            for j in F[t+1]:
                if (t,p,j) not in y:
                    continue
                for k in F[t+2]:
                    if (t+1,j,k) not in y:
                        continue
                    vx1 = j[0]-p[0]; vy1 = j[1]-p[1]
                    vx2 = k[0]-j[0]; vy2 = k[1]-j[1]
                    acc = (vx2-vx1)**2 + (vy2-vy1)**2
                    objective += inst.w_smooth * acc * y[(t,p,j)] * y[(t+1,j,k)]

    cqm.set_objective(objective)
    return cqm, inst, F, x, y

if __name__ == '__main__':
    cqm, inst, F, x, y = build_cqm()
    summary = {
        'num_x_vars': len(x),
        'num_y_vars': len(y),
        'num_constraints': len(cqm.constraints),
        'num_variables': len(cqm.variables),
        'feasible_counts': [len(s) for s in F],
    }
    out = Path(__file__).resolve().parents[1] / 'outputs' / 'cqm_model_summary.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))

    # Example D-Wave submission (requires configured Leap access):
    # from dwave.system import LeapHybridCQMSampler
    # sampler = LeapHybridCQMSampler()
    # sampleset = sampler.sample_cqm(cqm, time_limit=60)
    # feasible = sampleset.filter(lambda d: d.is_feasible)
    # print(feasible.first)
