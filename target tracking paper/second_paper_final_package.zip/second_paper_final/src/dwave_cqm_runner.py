"""
D-Wave CQM runner for the occlusion-aware target-tracking instance.

This file builds the same CQM objective used by the CP-SAT smoothness model.
It can always write a model summary. To submit to D-Wave Leap, install
D-Wave Ocean packages and configure DWAVE_API_TOKEN / dwave config.

Usage from project root:
    python src/dwave_cqm_runner.py --summary-only
    python src/dwave_cqm_runner.py --submit --time-limit 60
"""
from __future__ import annotations
from pathlib import Path
import argparse, json, math, time
from occlusion_tracking_core import (
    make_demo_instance, feasible_sets, valid_transition, dist, obstacle_risk,
    evaluate_path
)

try:
    import dimod
except Exception as e:
    dimod = None


def build_cqm():
    if dimod is None:
        raise RuntimeError("dimod is not installed. Run: python -m pip install dimod dwave-system")
    inst = make_demo_instance()
    F = feasible_sets(inst)
    cqm = dimod.ConstrainedQuadraticModel()

    x = {}
    for t, Ft in enumerate(F):
        for p in Ft:
            x[(t, p)] = dimod.Binary(f"x_{t}_{p[0]}_{p[1]}")

    y = {}
    for t in range(inst.T):
        for p in F[t]:
            for q in F[t + 1]:
                if valid_transition(inst, p, q):
                    y[(t, p, q)] = dimod.Binary(f"y_{t}_{p[0]}_{p[1]}__{q[0]}_{q[1]}")

    # One selected position at each time.
    for t, Ft in enumerate(F):
        cqm.add_constraint(sum(x[(t, p)] for p in Ft) == 1, label=f"one_position_t{t}")

    cqm.add_constraint(x[(0, inst.start)] == 1, label="start_position")

    # Flow constraints: selected states must be connected by a selected transition.
    for t in range(inst.T):
        for p in F[t]:
            out = [y[(t, p, q)] for q in F[t + 1] if (t, p, q) in y]
            cqm.add_constraint(sum(out) - x[(t, p)] == 0, label=f"out_{t}_{p[0]}_{p[1]}")
        for q in F[t + 1]:
            inc = [y[(t, p, q)] for p in F[t] if (t, p, q) in y]
            cqm.add_constraint(sum(inc) - x[(t + 1, q)] == 0, label=f"in_{t+1}_{q[0]}_{q[1]}")

    obs = set(inst.obstacles)
    objective = 0
    linear_terms = 0
    quadratic_terms = 0
    for (t, p, q), var in y.items():
        coeff = (
            inst.w_len * dist(p, q)
            + inst.w_track * (dist(q, inst.target[t + 1]) - inst.desired_d) ** 2
            + inst.w_obs * obstacle_risk(q, obs)
        )
        objective += coeff * var
        linear_terms += 1

    # CQM supports this quadratic smoothness objective directly.
    for t in range(inst.T - 1):
        for p in F[t]:
            for q in F[t + 1]:
                if (t, p, q) not in y:
                    continue
                for k in F[t + 2]:
                    if (t + 1, q, k) not in y:
                        continue
                    ax = (k[0] - q[0]) - (q[0] - p[0])
                    ay = (k[1] - q[1]) - (q[1] - p[1])
                    acc = ax * ax + ay * ay
                    if acc:
                        objective += inst.w_smooth * acc * y[(t, p, q)] * y[(t + 1, q, k)]
                    quadratic_terms += 1

    cqm.set_objective(objective)
    stats = {
        "num_x_vars": len(x),
        "num_y_vars": len(y),
        "num_variables": len(cqm.variables),
        "num_constraints": len(cqm.constraints),
        "num_linear_objective_terms": linear_terms,
        "num_quadratic_smoothness_candidates": quadratic_terms,
        "feasible_counts": [len(s) for s in F],
        "T": inst.T,
        "grid": [inst.W, inst.H],
        "obstacles": inst.obstacles,
        "target": inst.target,
    }
    return cqm, inst, F, x, y, stats


def decode_sample(sample, inst, F, x):
    path = []
    for t, Ft in enumerate(F):
        chosen = []
        for p in Ft:
            var = f"x_{t}_{p[0]}_{p[1]}"
            if sample.get(var, 0) > 0.5:
                chosen.append(p)
        if not chosen:
            path.append(None)
        else:
            path.append(chosen[0])
    if any(p is None for p in path):
        return path, {"feasible": False, "reasons": ["missing selected state"]}
    return path, evaluate_path(inst, path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary-only", action="store_true", help="Build CQM and write model summary only.")
    parser.add_argument("--submit", action="store_true", help="Submit to D-Wave LeapHybridCQMSampler.")
    parser.add_argument("--time-limit", type=float, default=60.0)
    args = parser.parse_args()

    outdir = Path(__file__).resolve().parents[1] / "outputs"
    outdir.mkdir(exist_ok=True)

    try:
        cqm, inst, F, x, y, stats = build_cqm()
    except Exception as e:
        fallback = {
            "status": "CQM_NOT_BUILT",
            "reason": str(e),
            "note": "Install dimod and dwave-system, then run again.",
            "expected_from_cpsat_counts": {
                "num_x_vars": 499,
                "num_y_vars": 3461,
                "num_quadratic_smoothness_candidates": 23311,
            },
        }
        (outdir / "dwave_cqm_summary.json").write_text(json.dumps(fallback, indent=2))
        print(json.dumps(fallback, indent=2))
        return

    summary_path = outdir / "dwave_cqm_summary.json"
    summary_path.write_text(json.dumps(stats, indent=2))
    print(json.dumps(stats, indent=2))

    if not args.submit:
        return

    from dwave.system import LeapHybridCQMSampler
    sampler = LeapHybridCQMSampler()
    t0 = time.time()
    sampleset = sampler.sample_cqm(cqm, time_limit=args.time_limit)
    wall = time.time() - t0
    feasible = sampleset.filter(lambda d: d.is_feasible)
    result = {
        "status": "SUBMITTED",
        "wall_time_s": wall,
        "time_limit_s": args.time_limit,
        "num_samples": len(sampleset),
        "num_feasible_samples": len(feasible),
        "best": None,
    }
    if len(feasible):
        rec = feasible.first
        path, metrics = decode_sample(rec.sample, inst, F, x)
        result["best"] = {
            "energy": rec.energy,
            "path": path,
            "metrics": metrics,
        }
    elif len(sampleset):
        rec = sampleset.first
        path, metrics = decode_sample(rec.sample, inst, F, x)
        result["best"] = {
            "energy": rec.energy,
            "path": path,
            "metrics": metrics,
            "warning": "No feasible CQM sample returned; showing lowest-energy sample.",
        }
    (outdir / "dwave_cqm_result.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
