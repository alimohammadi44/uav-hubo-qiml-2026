from __future__ import annotations
import json, os
from pathlib import Path
import matplotlib.pyplot as plt
from occlusion_tracking_core import make_demo_instance, solve_dp, feasible_sets, los_clear, bresenham

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs'
FIG = ROOT / 'figures'
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

inst = make_demo_instance()
sol = solve_dp(inst)
path = sol['path']

with open(OUT/'demo_solution.json','w') as f:
    json.dump({
        'instance': {
            'W': inst.W, 'H': inst.H, 'T': inst.T, 'target': inst.target,
            'obstacles': inst.obstacles, 'start': inst.start, 'd_min': inst.d_min,
            'd_max': inst.d_max, 'v_max': inst.v_max, 'desired_d': inst.desired_d,
        },
        'solution': sol,
    }, f, indent=2)

# Plot grid, obstacle cells, target trajectory, and optimized chaser path.
fig, ax = plt.subplots(figsize=(6.8,6.0))
# grid lines
for x in range(inst.W+1):
    ax.plot([x-0.5,x-0.5],[-0.5,inst.H-0.5],lw=0.3)
for y in range(inst.H+1):
    ax.plot([-0.5,inst.W-0.5],[y-0.5,y-0.5],lw=0.3)
# obstacles
for x,y in inst.obstacles:
    ax.add_patch(plt.Rectangle((x-0.5,y-0.5),1,1,alpha=0.45))
# target trajectory
xt=[p[0] for p in inst.target]; yt=[p[1] for p in inst.target]
ax.plot(xt,yt,'o--',label='Target trajectory')
# chaser path
xp=[p[0] for p in path]; yp=[p[1] for p in path]
ax.plot(xp,yp,'s-',label='Optimized UAV/chaser path')
# LOS rays at a few times
for t in [0,3,6,9,11]:
    ax.plot([path[t][0], inst.target[t][0]],[path[t][1], inst.target[t][1]],':',lw=1)
ax.scatter([inst.start[0]],[inst.start[1]],s=120,marker='*',label='Start')
ax.scatter([inst.target[-1][0]],[inst.target[-1][1]],s=120,marker='X',label='Final target')
ax.set_xlim(-0.5, inst.W-0.5); ax.set_ylim(-0.5, inst.H-0.5)
ax.set_aspect('equal')
ax.set_title('Demo: occlusion-aware UAV target tracking')
ax.set_xlabel('x cell'); ax.set_ylabel('y cell')
ax.legend(loc='upper left', fontsize=8)
fig.tight_layout()
fig.savefig(FIG/'demo_occlusion_tracking_path.png', dpi=220)
print(json.dumps({'path': path, 'metrics': sol['metrics'], 'output_json': str(OUT/'demo_solution.json'), 'figure': str(FIG/'demo_occlusion_tracking_path.png')}, indent=2))
